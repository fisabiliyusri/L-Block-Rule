#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

#UnlockbokepDanIzinoff
#kucingpeduli
iptables -t nat -I PREROUTING -p tcp --dport 80 -d nekopoi.care -j DNAT --to-destination 104.27.203.89
iptables -t nat -I PREROUTING -p tcp --dport 443 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A OUTPUT -p tcp --dport 80 -d nekopoi.care -j DNAT --to-destination 104.27.203.89
iptables -t nat -A OUTPUT -p tcp --dport 443 -d nekopoi.care -j DNAT --to-destination 104.27.203.89
iptables -t nat -A OUTPUT -p tcp --dport 443 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A OUTPUT -p tcp --dport 80 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A INPUT -p tcp --dport 443 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A INPUT -p tcp --dport 80 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A FORWARD -p tcp --dport 443 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -t nat -A FORWARD -p tcp --dport 80 -d nekopoi.care -j DNAT --to-destination 104.27.204.89
iptables -A PREROUTING -t nat -p tcp --dport 80 -d nekopoi.care -j REDIRECT --to-destination 104.27.203.89:80
iptables -A OUTPUT -t nat -p tcp --dport 80 -d nekopoi.care -j REDIRECT --to-destination 104.27.203.89:80
iptables -A PREROUTING -t nat -p tcp --dport 443 -d nekopoi.care -j REDIRECT --to-destination 104.27.203.89:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d nekopoi.care -j REDIRECT --to-destination 104.27.203.89:443


#coba
iptables -t nat -I PREROUTING -p tcp --dport 80 -d 185.88.181.53 -j DNAT --to-destination www.xnxx.com
iptables -t nat -I PREROUTING -p tcp --dport 443 -d 185.88.181.53 -j DNAT --to-destination www.xnxx.com
iptables -t nat -A OUTPUT -p tcp --dport 443 -d 185.88.181.53 -j DNAT --to-destination www.xnxx.com
iptables -t nat -A FORWARD -p tcp --dport 443 -d 185.88.181.53 -j DNAT --to-destination www.xnxx.com
iptables -A OUTPUT -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination www.xnxx.com
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination www.xnxx.com
#xnxx
iptables -t nat -I PREROUTING -p tcp --dport 80 -d www.xnxx.com -j DNAT --to-destination 185.88.181.59
iptables -t nat -I PREROUTING -p tcp --dport 443 -d www.xnxx.com -j DNAT --to-destination 185.88.181.59
iptables -t nat -A OUTPUT -p tcp --dport 80 -d www.xnxx.com -j DNAT --to-destination 185.88.181.59
iptables -t nat -A OUTPUT -p tcp --dport 443 -d www.xnxx.com -j DNAT --to-destination 185.88.181.59
iptables -t nat -A FORWARD -p tcp --dport 443 -d www.xnxx.com -j DNAT --to-destination 185.88.181.59
iptables -A INPUT -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.60:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.59:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.54:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.53:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.58:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.55:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.57:443
iptables -A PREROUTING -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.59:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.59:443
iptables -A PREROUTING -t nat -p tcp --dport 80 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.59:80
iptables -A OUTPUT -t nat -p tcp --dport 80 -d www.xnxx.com -j REDIRECT --to-destination 185.88.181.59:80

#nhentai
iptables -t nat -I PREROUTING -p tcp --dport 80 -d static.nhentai.net -j DNAT --to-destination 172.67.159.231
iptables -t nat -I PREROUTING -p tcp --dport 443 -d static.nhentai.net -j DNAT --to-destination 172.67.159.231
iptables -t nat -A OUTPUT -p tcp --dport 80 -d static.nhentai.net -j DNAT --to-destination 172.67.159.231
iptables -t nat -A FORWARD -p tcp --dport 80 -d static.nhentai.net -j DNAT --to-destination 172.67.159.231
iptables -A PREROUTING -t nat -p tcp --dport 443 -d static.nhentai.net -j REDIRECT --to-destination 172.67.159.231:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d static.nhentai.net -j REDIRECT --to-destination 172.67.159.231:443
iptables -A INPUT -t nat -p tcp --dport 443 -d static.nhentai.net -j REDIRECT --to-destination 172.67.159.231:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d static.nhentai.net -j REDIRECT --to-destination 172.67.159.231:443

#coba
iptables -t nat -I PREROUTING -p tcp --dport 80 -d 104.21.66.123 -j DNAT --to-destination nhentai.net
iptables -t nat -I PREROUTING -p tcp --dport 443 -d 104.21.66.123 -j DNAT --to-destination nhentai.net
iptables -t nat -A OUTPUT -p tcp --dport 443 -d 104.21.66.123 -j DNAT --to-destination nhentai.net
iptables -t nat -A FORWARD -p tcp --dport 443 -d 104.21.66.123 -j DNAT --to-destination nhentai.net
iptables -A OUTPUT -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination nhentai.net
iptables -A FORWARD -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination nhentai.net

#nhentai
iptables -t nat -I PREROUTING -p tcp --dport 80 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -t nat -I PREROUTING -p tcp --dport 443 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -t nat -A OUTPUT -p tcp --dport 80 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -t nat -A FORWARD -p tcp --dport 80 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -t nat -A OUTPUT -p tcp --dport 443 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -t nat -A FORWARD -p tcp --dport 443 -d nhentai.net -j DNAT --to-destination 104.21.66.123
iptables -A PREROUTING -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination 104.21.66.123:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination 104.21.66.123:443
iptables -A INPUT -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination 104.21.66.123:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d nhentai.net -j REDIRECT --to-destination 104.21.66.123:443

#t5
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443

#185.177.127.77 i5.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d i5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d i5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A INPUT -t nat -p tcp --dport 443 -d i5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d i5.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443

#185.177.127.77 t.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443

#185.107.44.3 t.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443

#185.107.44.3 t2.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t2.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t2.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t2.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t2.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443

#185.107.44.3 t3.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t3.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t3.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t3.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t3.nhentai.net -j REDIRECT --to-destination 185.107.44.3:443

#185.177.127.78 t.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443

#185.177.127.78 t7.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d t7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d t7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A INPUT -t nat -p tcp --dport 443 -d t7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d t7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443

#185.177.127.78 i7.nhentai.net
iptables -A PREROUTING -t nat -p tcp --dport 443 -d i7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d i7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A INPUT -t nat -p tcp --dport 443 -d i7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d i7.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443

#
iptables -A PREROUTING -t nat -p tcp --dport 443 -d i.nhentai.net -j REDIRECT --to-destination 185.177.127.77:443
iptables -A OUTPUT -t nat -p tcp --dport 443 -d i.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A INPUT -t nat -p tcp --dport 443 -d i.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443
iptables -A FORWARD -t nat -p tcp --dport 443 -d i.nhentai.net -j REDIRECT --to-destination 185.177.127.78:443

#IzinInternetdanblockiklan
#iptables -A INPUT -i lo -j ACCEPT
#iptables -A OUTPUT -o lo -j ACCEPT
#iptables -A OUTPUT -o tun+ -j ACCEPT
#iptables -A INPUT -i tun+ -j ACCEPT
iptables -A OUTPUT -i wlan0 -d www.google.com -p tcp --dport 80 -j ACCEPT
iptables -A OUTPUT -i wlan0 -d www.google.com -p tcp --dport 443 -j ACCEPT
iptables -A FORWARD -i wlan0 -d www.google.com -p tcp --dport 80 -j ACCEPT
iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -i wlan0 -d zippyshare.com -p tcp --dport 80 -j ACCEPT
iptables -A OUTPUT -i wlan0 -d zippyshare.com -p tcp --dport 443 -j ACCEPT
iptables -A FORWARD -i wlan0 -d zippyshare.com -p tcp --dport 80 -j ACCEPT
iptables -A FORWARD -i wlan0 -d zippyshare.com -p tcp --dport 443 -j ACCEPT
iptables -A OUTPUT -m string --string ".zippyshare.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".zippyshare.com" --algo bm -j ACCEPT
iptables -A FORWARD -m string --string ".zippyshare.com" --algo bm -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,53 -s 145.0.0/8 -j ACCEPT
iptables -A OUTPUT -p udp -m multiport --dports 80,443,53 -s 145.0.0/8 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,53 -s 145.0.0/8 -j ACCEPT
iptables -A FORWARD -p tcp -m multiport --dports 80,443,53 -s 145.0.0/8 -j ACCEPT
iptables -A OUTPUT -p udp --dport 853 -j ACCEPT
iptables -A INPUT -p udp --sport 853 -j ACCEPT
iptables -A FORWARD -p udp --sport 853 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 853 -j ACCEPT
iptables -A INPUT -p tcp --sport 853 -j ACCEPT
iptables -A FORWARD -p tcp --sport 853 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
iptables -A INPUT -p tcp --sport 53 -j ACCEPT
iptables -A FORWARD -p tcp --sport 53 -j ACCEPT
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 53 -j ACCEPT
iptables -A FORWARD -p udp --sport 53 -j ACCEPT
iptables -A INPUT -s 192.168.1.0/24 -j ACCEPT
#iptables -A INPUT -p tcp -m multiport --destination-ports 22,25,53,80,443,465,5222,5269,5280,8999:9003 -j ACCEPT
#iptables -A INPUT -p udp -m multiport --destination-ports 53 -j ACCEPT
iptables -A OUTPUT -p udp -o eth0 --dport 53 -j ACCEPT
iptables -A OUTPUT -p udp -o wlan0 --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 104.16.0.0/13 -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 104.24.0.0/14 -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 172.64.0.0/13 -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 162.158.0.0/15 -j ACCEPT
iptables -A OUTPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 131.0.72.0/22 -j ACCEPT
iptables -A OUTPUT -s 46.166.139.0/24 -j ACCEPT
iptables -A FORWARD -s 46.166.139.0/24 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 104.16.0.0/13 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 104.24.0.0/14 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 172.64.0.0/13 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 162.158.0.0/15 -j ACCEPT
iptables -A INPUT -p tcp -m multiport --dports 80,443,8080,8443,2052,2053,2082,2083,2086,2087,2095,2096,8880 -s 131.0.72.0/22 -j ACCEPT
iptables -A INPUT -s 8.8.8.0/24 -j ACCEPT
iptables -A FORWARD -s 8.8.8.0/24 -j ACCEPT
iptables -A OUTPUT -s 8.8.8.0/24 -j ACCEPT
iptables -A INPUT -s 8.8.4.0/24 -j ACCEPT
iptables -A FORWARD -s 8.8.4.0/24 -j ACCEPT
iptables -A OUTPUT -s 8.8.4.0/24 -j ACCEPT
iptables -A OUTPUT -d 1.1.1.1 -j ACCEPT
iptables -A INPUT -d 1.1.1.1 -j ACCEPT
iptables -A FORWARD -d 1.1.1.1 -j ACCEPT
iptables -A FORWARD -s 104.16.0.0/13 -j ACCEPT
iptables -A FORWARD -s 104.24.0.0/14 -j ACCEPT
iptables -A FORWARD -s 172.64.0.0/13 -j ACCEPT
iptables -A OUTPUT -s 104.16.0.0/13 -j ACCEPT
iptables -A OUTPUT -s 104.24.0.0/14 -j ACCEPT
iptables -A OUTPUT -s 172.64.0.0/13 -j ACCEPT
iptables -A OUTPUT -s 162.62.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 143.204.0.0/14 -j ACCEPT
iptables -A OUTPUT -s 34.149.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 104.75.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.35.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.205.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 96.16.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 34.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 35.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 36.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 114.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 125.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 43.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 104.0.0.0/8 -j ACCEPT
iptables -A INPUT -s 104.0.0.0/8 -j ACCEPT
iptables -A FORWARD -s 104.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 23.36.0.0/16 -j ACCEPT
iptables -A INPUT -s 23.36.0.0/16 -j ACCEPT
iptables -A FORWARD -s 23.36.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.32.0.0/16 -j ACCEPT
iptables -A INPUT -s 23.32.0.0/16 -j ACCEPT
iptables -A FORWARD -s 23.32.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 157.0.0.0/8 -j ACCEPT
iptables -A INPUT -s 157.0.0.0/8 -j ACCEPT
iptables -A FORWARD -s 157.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 69.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 31.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 69.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 66.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 173.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 103.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 179.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 129.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 163.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 61.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 118.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 180.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 184.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 110.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 222.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 23.221.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.220.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.32.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.193.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.95.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 23.2.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 145.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 217.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 46.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 108.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 18.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 54.0.0.0/8 -j ACCEPT
iptables -A OUTPUT -s 74.114.24.0/21 -j ACCEPT
iptables -A OUTPUT -s 74.125.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 142.250.0.0/15 -j ACCEPT
iptables -A OUTPUT -s 172.110.32.0/21 -j ACCEPT
iptables -A OUTPUT -s 172.217.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 172.253.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 45.133.44.0/24 -j DROP
iptables -A OUTPUT -s 45.13.3.0/24 -j DROP
iptables -A INPUT -s 45.133.44.0/24 -j DROP
iptables -A INPUT -s 45.13.3.0/24 -j DROP
iptables -A FORWARD -s 45.133.44.0/24 -j DROP
iptables -A FORWARD -s 45.13.3.0/24 -j DROP
iptables -A OUTPUT -p tcp -d 45.133.44.0/24 -j DROP
iptables -A OUTPUT -p tcp -d 45.13.3.0/24 -j DROP
iptables -A OUTPUT -p udp -d 45.133.44.0/24 -j DROP
iptables -A OUTPUT -p udp -d 45.13.3.0/24 -j DROP
iptables -A OUTPUT -p tcp -d 203.195.121.0/24 -j DROP
iptables -A OUTPUT -p udp -d 203.195.121.0/24 -j DROP
iptables -A OUTPUT -p tcp -d 188.42.84.0/24 -j DROP
iptables -A OUTPUT -p udp -d 188.42.84.0/24 -j DROP
iptables -A OUTPUT -d 203.195.121.0/24 -j DROP
iptables -A OUTPUT -d 188.42.84.0/24 -j DROP
iptables -A OUTPUT -d 8.244.0.0/14 -j DROP
iptables -A OUTPUT -d 8.248.0.0/13 -j DROP
iptables -A OUTPUT -d 142.91.159.0/24 -j DROP
iptables -A OUTPUT -d 23.109.248.0/24 -j DROP
iptables -A OUTPUT -d 23.109.82.0/24 -j DROP
iptables -A OUTPUT -d 23.109.87.0/24 -j DROP
iptables -A OUTPUT -d 139.45.195.0/24 -j DROP
iptables -A OUTPUT -d 139.45.196.0/23 -j DROP
iptables -A OUTPUT -d 139.45.192.0/18 -j DROP
#untuk ff
iptables -A INPUT -s 202.81.0.0/16 -j ACCEPT
iptables -A INPUT -s 31.13.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 202.81.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 31.13.0.0/16 -j ACCEPT
iptables -A FORWARD -s 202.81.0.0/16 -j ACCEPT
iptables -A FORWARD -s 31.13.0.0/16 -j ACCEPT
iptables -A INPUT -s 143.92.0.0/16 -j ACCEPT
iptables -A INPUT -s 103.247.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 143.92.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 103.247.0.0/16 -j ACCEPT
iptables -A FORWARD -s 143.92.0.0/16 -j ACCEPT
iptables -A FORWARD -s 103.247.0.0/16 -j ACCEPT
iptables -A INPUT -s 202.181.0.0/16 -j ACCEPT
iptables -A OUTPUT -s 202.181.0.0/16 -j ACCEPT
iptables -A FORWARD -s 202.181.0.0/16 -j ACCEPT
#untukgame
iptables -A INPUT -m string --string "accounts" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "accounts" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "freefiremobile" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "freefiremobile" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "garena" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "garena" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "pubg" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "pubg" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "akamaized" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "akamaized" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "mobilelegends" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "mobilelegends" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".igamecj.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".krafton.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".gjacky.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".anticheatexpert.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".tdatamaster.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".amsoveasea.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".gcloudcs.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".proximabeta.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".akamaihd.net" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".youngjoygame.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".aihelp.net" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".mobilelegends.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".yuanzhanapp.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string ".taobao.com" --algo bm -j ACCEPT
#untukblock
iptables -A INPUT -m string --string "ahacdn" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ahacdn" --algo bm -j DROP
iptables -A INPUT -m string --string ".ahacdn." --algo bm -j DROP
iptables -A OUTPUT -m string --string ".ahacdn." --algo bm -j DROP
iptables -A INPUT -m string --string "samghasps" --algo bm -j DROP
iptables -A OUTPUT -m string --string "samghasps" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".ads." --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads." --algo bm -j DROP
iptables -A OUTPUT -m string --string "tpc." --algo bm -j DROP
iptables -A OUTPUT -m string --string "acacdn." --algo bm -j DROP
iptables -A OUTPUT -m string --string "asacdn." --algo bm -j DROP
iptables -A OUTPUT -m string --string "mgid" --algo bm -j DROP
iptables -A OUTPUT -m string --string "trackneo" --algo bm -j DROP
iptables -A OUTPUT -m string --string "realsrv" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adsco" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserv" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bebi" --algo bm -j DROP
iptables -A OUTPUT -m string --string "syndicate" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tsyndicate" --algo bm -j DROP
iptables -A OUTPUT -m string --string "supersonicads" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".website" --algo bm -j DROP
iptables -A OUTPUT -m string --string "us.phone-to-clean.club" --algo bm -j DROP
iptables -A INPUT -m string --string ".casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".casa" --algo bm -j DROP
iptables -A INPUT -m string --string "doubleclick" --algo bm -j DROP
iptables -A OUTPUT -m string --string "doubleclick" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pagead" --algo bm -j DROP
iptables -A OUTPUT -m string --string "googleads" --algo bm -j DROP
iptables -A OUTPUT -m string --string "applovin" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adskeeper" --algo bm -j DROP
iptables -A OUTPUT -m string --string "viglink" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tempest" --algo bm -j DROP
iptables -A OUTPUT -m string --string "popads" --algo bm -j DROP
iptables -A OUTPUT -m string --string "fusetracking" --algo bm -j DROP
iptables -A OUTPUT -m string --string "-tracking" --algo bm -j DROP
iptables -A OUTPUT -m string --string "infolinks" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tubecup" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mcpuwpush" --algo bm -j DROP
iptables -A OUTPUT -m string --string "metricswpsh" --algo bm -j DROP
iptables -A OUTPUT -m string --string "flurry" --algo bm -j DROP
iptables -A OUTPUT -m string --string "histats" --algo bm -j DROP
iptables -A OUTPUT -m string --string "casalemedia" --algo bm -j DROP
iptables -A OUTPUT -m string --string "juicyads" --algo bm -j DROP
iptables -A OUTPUT -m string --string "poweredbyliquidfire" --algo bm -j DROP
iptables -A OUTPUT -m string --string "paychat" --algo bm -j DROP
iptables -A OUTPUT -m string --string "popin" --algo bm -j DROP
iptables -A OUTPUT -m string --string "crwdcntrl" --algo bm -j DROP
iptables -A FORWARD -m string --string "youtube.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "googlevideo.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "google.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "facebook.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "zippyshare.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "gtarcade.com" --algo bm -j ACCEPT
iptables -A INPUT -m string --string "gtarcade.com" --algo bm -j ACCEPT
iptables -A FORWARD -m string --string "gtarcade.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "sni.cloudflaressl.com" --algo bm -j ACCEPT
iptables -A FORWARD -m string --string "sni.cloudflaressl.com" --algo bm -j ACCEPT
iptables -A OUTPUT -m string --string "data-beacons.s-onetag.com" --algo bm -j DROP
iptables -A INPUT -m string --string "data-beacons.s-onetag.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "data-beacons.s-onetag.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "ticketswinning.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ticketswinning.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "img.rtbsystem.org" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "servicer.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clck.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "exchange.adtrue.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".adtrue.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".top" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".cc" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".tr" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".ro" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".re" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".tr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserver.webads.nl" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".de" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".it" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".gr" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".hu" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".kr" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".fr" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".lv" --algo bm -j DROP
iptables -A OUTPUT -m string --string "referrer." --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserver" --algo bm -j DROP
iptables -A OUTPUT -m string --string ".jads" --algo bm -j DROP
iptables -A OUTPUT -m string --string "blogger.googleusercontent.com" --algo bm -j DROP
iptables -A INPUT -m string --string "blogger.googleusercontent.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "blogger.googleusercontent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "photos-ugc.l.googleusercontent.com" --algo bm -j DROP
iptables -A INPUT -m string --string "photos-ugc.l.googleusercontent.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "photos-ugc.l.googleusercontent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "1.bp.blogspot.com" --algo bm -j DROP
iptables -A INPUT -m string --string "1.bp.blogspot.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "1.bp.blogspot.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "3.bp.blogspot.com" --algo bm -j DROP
iptables -A INPUT -m string --string "3.bp.blogspot.com" --algo bm -j DROP
iptables -A FORWARD -m string --string "3.bp.blogspot.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ngp4.mybetterck.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ntlyenclothe.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "soaheeme.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ithyourretye.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.maxonclick.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "crrepo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ds88pc0kw6cvc.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rmationeng.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d10lumateci472.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clksite.com" --algo bm -j DROP
iptables -A INPUT -m string --string "clksite" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clksite" --algo bm -j DROP
iptables -A FORWARD -m string --string "clksite" --algo bm -j DROP
iptables -A OUTPUT -m string --string "encloseddealing.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ticketswinning.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "v1.addthisedge.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "exchangediscreditmast.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.barscreative1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.sb4you1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "simplewebanalysis.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s7.addthis.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "specialistcorrelation.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "aphycolourses.info" --algo bm -j DROP
iptables -A OUTPUT -m string --string "freychang.fun" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rmationeng.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "syndication.exdynsrv.com
iptables -A OUTPUT -m string --string "samghasps.com" --algo bm -j DROP
iptables -A INPUT -m string --string "samghasps.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.exdynsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "begrimdos.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "fp.metricswpsh.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "kewhulawi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "estoyads.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "octanmystes.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "chusewhereer.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mirishkeeps.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.barscreative1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "c1.popads.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.xthizbdwgebzqf.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "eshouloo.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ulhktrnb.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "my.rtmark.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "diromalxx.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "glitter.services.disqus.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "propeller-tracking.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gredraus.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "soaheeme.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "diqcodclkwy.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "links.services.disqus.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ueljsnslvgyuoa.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad360global.trackneo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ashoupsu.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ibpijeuwqe.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "css.gbtcdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "uidesign.gbtcdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gloimg.gbtcdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad360global.trackneo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "giwbpwvqafsfjyv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "oolraimt.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ashierbowler.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "amplitudewassnap.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "hyotqlcmdejorv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "eu.freshpops.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.adx1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.adf.ly" --algo bm -j DROP
iptables -A OUTPUT -m string --string "curdlecobiron.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "malthustutball.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "trafficfantasy.fusetracking.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "slotcasino188.co" --algo bm -j DROP
iptables -A OUTPUT -m string --string "g1.v.fwmrm.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "us.phone-to-clean.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "7.passfixx.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mcpuwpush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "invol.co" --algo bm -j DROP
iptables -A OUTPUT -m string --string "furstraitsbrowse.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.barscreative1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "sentimenthypocrisy.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "firsthanddisagree.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "unforgivablegrowl.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.cloudimagesb.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "chingari.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "joygaskin.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "easygoingasperitydisconnect.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "guardianinvadecrept.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "un.pedagogsecreta.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cableddaffed.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "phallicuncut.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "elementalantecedent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.exosrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "syndication.exosrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s.optnx.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "powerad.ai" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.pubmatic.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "hb.brainlyads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "eus.rubiconproject.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cmp.uniconsent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dsh7ky7308k4b.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "script.4dex.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "c.amazon-adsystem.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clickadilla.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a1b9b0c7d1.d8fb9b701c.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.wpshsdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pcceurope.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gateway.arc.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "elfinsande.website" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.jnkstff.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getels.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getapo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getnee.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getcong.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getotal.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getove.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getony.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getmari.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getwil.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gettran.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getnapa.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getyong.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gettine.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getkel.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "getibo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "exchange.adtrue.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.adtrue.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn-adtrue.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "catx.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "t.go2.global" --algo bm -j DROP
iptables -A OUTPUT -m string --string "hopefullyapricot.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "id.agtechconf.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "lotteryhibernateauthorized.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "revolvefarfetched.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "sosigninggrudge.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "simplewebanalysis.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clenchedyouthmatching.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.cloudimagesb.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "grandchildfee.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "latentcreeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "binderyjenna.website" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cableddaffed.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.uponelectabuzzor.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "untimburra.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "zg.twingedapoda.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bocglrgwlckim.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bocglrgwlckim.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "arecmesi.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "st.chatango.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ust.chatango.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "api2.branch.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dnhfi5nn2dt67.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "freychang.fun" --algo bm -j DROP
iptables -A OUTPUT -m string --string "haphazardhum.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "softballwaiting.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "regulationprivilegescan.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "venetrigni.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ja2n2u30a6rgyd.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "salutationcheerlessdemote.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "baradoot.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dateddeed.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "nwpyzaqlbbtd.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.nwpyzaqlbbtd.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "paychat.fuse-cloud.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "blastcahs.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "woundedassurance.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.uozrikpw.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "khovdimina.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "blastcahs.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clerrrep.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d1f05vr3sjsuy7.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d18t35yyry2k49.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pringed.space" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserver.kl-youniverse.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdns.klimg.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tags.crwdcntrl.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "in.treasuredata.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "playerseo.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "p.adsymptotic.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rspctdown.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bepiletussar.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "newtontanrec.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mersionbronze.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "enginsquawks.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "luxury138.link" --algo bm -j DROP
iptables -A OUTPUT -m string --string "buncoswosh.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "repsrowedpay.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "monasawaw.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pixel.onaudience.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "data-beacons.s-onetag.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tags.bluekai.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bcp.crwdcntrl.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "t.dtscout.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "playerseo.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "i-sg.magazine.heytapmobile.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "image.freepik.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "x.bidswitch.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "token.rubiconproject.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js-sec.indexww.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a4564.casalemedia.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "app.adjust.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn-f.adsmoloco.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.doubleverify.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "sync.teads.tv" --algo bm -j DROP
iptables -A OUTPUT -m string --string "partners.tremorhub.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ssum-sec.casalemedia.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "api.flat-ads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mpx.mopub.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cb.mopub.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.mopub.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adrta.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dsp-adcreative.mobshark.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.taboola.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "data.flurry.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "jsc.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "c.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s-img.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.adskeeper.co.uk" --algo bm -j DROP
iptables -A OUTPUT -m string --string "servicer.adskeeper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "comasoiling.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "isletachoisya.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "spankerpuked.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adsmetadata.startappservice.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mileagechronic.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "addresseepaper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "venetrigni.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tapappalling.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dismantlepenantiterrorist.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "jsc.adskeeper.co.uk" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.antiadblocksystems.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d3cod80thn7qnd.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d24ak3f2b.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onalskillsexkc.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "exportspring.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "opertyvaluat.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s7.addthis.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "aphycolourses.info" --algo bm -j DROP
iptables -A OUTPUT -m string --string "z.moatads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clksite.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "kucinggembul.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "submissionhunk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.sb4you1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.barscreative1.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ds88pc0kw6cvc.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.maxonclick.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d10lumateci472.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.inmobi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "log.apk.v-mate.mobi" --algo bm -j DROP
iptables -A OUTPUT -m string --string "api.mobshark.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.inmobi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adx-dra.op.hicloud.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s.oksp.in" --algo bm -j DROP
iptables -A OUTPUT -m string --string "v.starhalo.mobi" --algo bm -j DROP
iptables -A OUTPUT -m string --string "quantcast.mgr.consensu.org
iptables -A OUTPUT -m string --string "propu.sh" --algo bm -j DROP
iptables -A OUTPUT -m string --string "postlnk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "staitchu.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "louchees.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "btloader.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "katukaunamiss.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "xml.howto5.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bepiletussar.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "comasoiling.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "isletachoisya.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "outoctillerytor.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.itphanpytor.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.itskiddoan.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tagcachedataxrt.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "offerimage.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tempest.services.disqus.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.adtng.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s4is.histats.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "x.disq.us" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pixel.tapad.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "p.rfihub.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "live.rezync.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "syndication.exdynsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "io.narrative.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "obgpm76tt0a0sgozk8l.npdredinuid.imrworldwide.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pippio.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.exdynsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "randallbesin.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "config.unityads.unity3d.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "wovazaix.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "static.cdnativepush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pubads.g.doubleclick.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cfg.flurry.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "flurry.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "compass.adop.cc" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adop.cc" --algo bm -j DROP
iptables -A OUTPUT -m string --string "api.adinplay.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tg1.playstream.media" --algo bm -j DROP
iptables -A OUTPUT -m string --string "compass.adop.cc" --algo bm -j DROP
iptables -A OUTPUT -m string --string "acdcdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.hostingcloud.racing" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.onclickalgo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads2.uptobox.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "i.wmgtr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "yfetyg.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "img.cdn.house" --algo bm -j DROP
iptables -A OUTPUT -m string --string "upgulpinon.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "wingersunbrand.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bedumbserugate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "t7z.cupid.iqiyi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "api16-access-sg.pangle.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adsco.re" --algo bm -j DROP
iptables -A OUTPUT -m string --string "c.adsco.re" --algo bm -j DROP
iptables -A OUTPUT -m string --string "l4.adsco.re" --algo bm -j DROP
iptables -A OUTPUT -m string --string "n4.adsco.re" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s4.adsco.re" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pertersacstyli.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "st.bebi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tracker.arc.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "prd.jwpltx.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "go.bebi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bebi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "code.yengo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "my.rtmark.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "denetsuk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "jomtingi.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "amandajuliett.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tokopedia.1atg0ub43h38.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "trk.bad-tool-tell-doubt.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "unpleasantconcrete.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pl16836679.effectivegatetocontent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "effectivegatetocontent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "run-syndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "lcdn.tsyndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pxl.tsyndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.runative-syndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tsyndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "toglooman.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.viglink.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "interstitial-07.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "propeller-tracking.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "oackoubs.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "in-page-push.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "static.cdnativepush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "video.tikzone.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "goajuzey.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "worersie.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "referrer.disqus.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "agacelebir.com" --algo bm -j DROP
iptables -A OUTPUT -p udp --dport 53 -m string --domain agacelebir.com -j DROP
iptables -A OUTPUT -m string --string "thaudray.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "usipucxjdat.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.displayvertising.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gadsabs.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "breedtagask.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "netfree.id" --algo bm -j DROP
iptables -A OUTPUT -m string --string "watzap.id" --algo bm -j DROP
iptables -A OUTPUT -m string --string "analytics.tiktok.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "distillery.wistia.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "client.crisp.chat" --algo bm -j DROP
iptables -A OUTPUT -m string --string "client.relay.crisp.chat" --algo bm -j DROP
iptables -A OUTPUT -m string --string "itineraryupper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "video.your-notice.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ecdn.analysis.fi" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ecdn.firstimpression.io" --algo bm -j DROP
iptables -A OUTPUT -m string --string "setpadchat.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.vdo.ai" --algo bm -j DROP
iptables -A OUTPUT -m string --string "xmllover.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "regulationprivilegescan.top" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.api.vungle.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "telemetry.sdk.inmobi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "events-dra.op.hicloud.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "outcome-ssp.supersonicads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pm-gateway.supersonicads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tnc16-alisg.isnssdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "init.supersonicads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "networksdk.ssacdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "go.hpyjmp.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "go.stripchat.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "img.strpst.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "creative.hpyjmp.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.tsyndicate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "na.nawpush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.wpushsdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rtbbnr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.natsdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.cabnnr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "serve.popads.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "wonderhsjnsd.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.wpadmngr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "thdifferuken.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "eu.rollmeout.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "berlipurplin.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "go.xxxiijmp.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "consequentlyinmate.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bongacams7.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.predictiondexchange.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bam-cell.nr-data.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "blockadsnot.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "forfrogadiertor.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pokreess.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.googletagservices.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d1u1byonn4po0b.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "d26adrx9c3n0mq.cloudfront.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "poodledopas.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "itemedjhvh.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "acrisialithic.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "lousebankroll.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "poweredby.jads.co" --algo bm -j DROP
iptables -A OUTPUT -m string --string "i.jads.co" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.juicyads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.juicyads.rocks" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.poweredbyliquidfire.mobi" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.capndr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.wpushsdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "puwpush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "vidvas3.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "whoutsog.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ptawhood.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "mondialwering.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.exosrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "couptoug.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "inpagepush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "egreephu.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "gibeleftyeuro.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "spoilphysiqueteenagers.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "direct.apus.tech" --algo bm -j DROP
iptables -A OUTPUT -m string --string "platform.bidgear.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "snagbaudhulas.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "geedoovu.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.cdn4ads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn4ads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "static.cloudflareinsights.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "paychat.fuse-cloud.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onclickgenius.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onclickperformance.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onclickalgo.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "l.sharethis.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "papayads.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "infolinks.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "thumbnails.infolinks.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rt3042.infolinks.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "player.adtelligent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "resources.infolinks.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onetag-sys.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rt3012.infolinks.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "lookereras.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "xml.pushcollection.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "feed.rexadvert.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "loxedchazan.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "resultsenraged.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "accesstra.de" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bt.udomyeasted.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "glassesoftruth.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "tcatholicyclea.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "assiumwor.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "xml.bid-engine.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ngp4.intnotif.club" --algo bm -j DROP
iptables -A OUTPUT -m string --string "crazyads.fusetracking.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a03.uadexchange.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.realsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cds.h5z9g8y6.hwcdn.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "syndication.realsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "s3t3d2y7.ackcdn.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "newvideoapp.pro" --algo bm -j DROP
iptables -A OUTPUT -m string --string "manytoon.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "a.realsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "realsrv.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "budgepoachaction.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "prunesmuggy.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "venetrigni.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "cdn.cloudimagesb.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "sterilecute.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "sinewedretore.casa" --algo bm -j DROP
iptables -A OUTPUT -m string --string "services.vlitag.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "trk.record-certainly-numeral-draw.xyz" --algo bm -j DROP
iptables -A OUTPUT -m string --string "installsadsphonemobile.cyou" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adsfs-id.heytapimg.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adx-id.ads.heytapmobile.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adx-id.ads.oppomobile.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.heytapmobile.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.oppomobile.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "amucksballone.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "banibajury.website" --algo bm -j DROP
iptables -A OUTPUT -m string --string "na.nawpush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ssp.zog.link" --algo bm -j DROP
iptables -A OUTPUT -m string --string "metricswpsh.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "r88.vn" --algo bm -j DROP
iptables -A OUTPUT -m string --string "zbet.vn" --algo bm -j DROP
iptables -A OUTPUT -m string --string "app.readpeak.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "kfiopkln.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "jsecoin.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.clickadu.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.eis.de" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.tipico.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad2.trafficgate.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.rssad.jp" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ya-distrib.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad.letmeads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.stumbleupon.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ads.glispa.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "click.hotlog.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "hitcounter.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "top.mail.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserv.ontek.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "izlenzi.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.installads.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "wensixuetang.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "hth107.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bcebos.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserver.webads.nl" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.kontakt-vermittler.de" --algo bm -j DROP
iptables -A OUTPUT -m string --string "marketing.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "brillen.de" --algo bm -j DROP
iptables -A OUTPUT -m string --string "affiliazioniads.snai.it" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adserver.html.it" --algo bm -j DROP
iptables -A OUTPUT -m string --string "affiliazioniads.snai.it" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pay4results24.eu" --algo bm -j DROP
iptables -A OUTPUT -m string --string "casinopro.se" --algo bm -j DROP
iptables -A OUTPUT -m string --string "doktor-se.onelink.me" --algo bm -j DROP
iptables -A OUTPUT -m string --string "adman.otenet.gr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "axiabanners.exodus.gr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "interactive.forthnet.gr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad.eval.hu" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ad.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "daserver.ul" --algo bm -j DROP
iptables -A OUTPUT -m string --string "traweb.hu" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.salidzini.lv" --algo bm -j DROP
iptables -A OUTPUT -m string --string "kingtoon.slnk.kr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "playdsb.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "aflam.info" --algo bm -j DROP
iptables -A OUTPUT -m string --string "booraq.org" --algo bm -j DROP
iptables -A OUTPUT -m string --string "dubizzle.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "promo.vador.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "weborama.fr" --algo bm -j DROP
iptables -A OUTPUT -m string --string "aff.sendhub.pl" --algo bm -j DROP
iptables -A OUTPUT -m string --string "advmanager.techfun.pl" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.trizer.pl" --algo bm -j DROP
iptables -A OUTPUT -m string --string "afftrk.altex.ro" --algo bm -j DROP
iptables -A OUTPUT -m string --string "blackfridaysales.ro" --algo bm -j DROP
iptables -A OUTPUT -m string --string "even.2performant.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "l.profitshare.ro" --algo bm -j DROP
iptables -A OUTPUT -m string --string "febrare.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "utimg.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "chikidiki.ru" --algo bm -j DROP
iptables -A OUTPUT -m string --string "i.wmgtr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "imlvrr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "i.wmgtr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "static.bookmsg.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "kts.vasstycom.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "notification.tubecup.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.wpushsdk.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "vidvas3.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "js.cabnnr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "rtbbnr.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "publishers.clickadilla.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "doigtepyramid.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "ntvpwpush.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "wdeliv.net" --algo bm -j DROP
iptables -A OUTPUT -m string --string "12112336.pix-cdn.org" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clickadilla.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "awigglespouter.cam" --algo bm -j DROP
iptables -A OUTPUT -m string --string "feuingcrche.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "addresseepaper.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "jobfilletfortitude.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "clenchedyouthmatching.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "venetrigni.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pl16013776.highrevenuecpm.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "pl16112730.gatetotrustednetwork.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "venetrigni.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "preventionpitcherremedy.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "www.effectivedisplaycontent.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "planningunavoidablenull.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "bedrapiona.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "onmarshtompor.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "e2ertt.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "perf.cdnads.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "iclickcdn.com" --algo bm -j DROP
iptables -A OUTPUT -m string --string "notification.tubecup.net" --algo bm -j DROP
